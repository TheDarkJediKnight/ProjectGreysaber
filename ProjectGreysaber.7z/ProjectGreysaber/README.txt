Hey y'all, T.D.J.K. here. 
Heck beyonds everything, I've been coding on and off for 5+ years, but never made much out of it.
...and now, and now... here I am making the framework for a project I wanted to do since a kid. 
This is kinda neato that I finally do.
I'm not sure how much I'll work on it over time, though like anything with me: 
if I get bored of it, I'll be back a few months from now.

Oh, one more thing, this is marked by The Unlicense, so it's means this project is public domain... for now.
What that means is I'm holding no vice or grip on this project, so if others see it and want to utilise stuff, go ahead.
One thing though: please ton't just rip it and claim it as your own. You found it first here, and not elsewhere.
Like I said, you can "use parts from it" does NOT mean copying 70+% of the whole thing. Try being somewhat original, m'kay?

Anyways, I'll stop the rant now, don't want to bore the peeps that read this README file...
